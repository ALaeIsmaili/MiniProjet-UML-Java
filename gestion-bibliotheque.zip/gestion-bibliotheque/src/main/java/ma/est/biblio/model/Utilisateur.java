package ma.est.biblio.model;

public class Utilisateur {
    private int id;
    private String username;
    private String role;
    private boolean estBloque;

    public Utilisateur(int id, String username, String role, boolean estBloque) {
        this.id = id;
        this.username = username;
        this.role = role;
        this.estBloque = estBloque;
    }

    // Getters
    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getRole() { return role; }
    public boolean isEstBloque() { return estBloque; }
}




