package ma.est.biblio.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    // NOTE: WAMP usually uses port 3308. XAMPP uses 3306.
    // Try changing 3306 to 3308 if the connection fails!
    private static final String URL = "jdbc:mysql://localhost:3306/biblio_db?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "alae2000"; 

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (Exception e) {
            System.err.println("❌ Database Error: " + e.getMessage());
            return null;
        }
    }

    // --- MAIN METHOD FOR TESTING ---
    // Right-click this file -> "Run As" -> "Java Application"
    public static void main(String[] args) {
        System.out.println("Testing connection to: " + URL);
        Connection conn = getConnection();
        
        if (conn != null) {
            System.out.println("✅ SUCCESS! Connected to the database.");
        } else {
            System.err.println("❌ FAILED! Could not connect.");
            System.err.println("Tip: Check if WAMP/XAMPP is running and if port 3306 or 3308 is correct.");
        }
    }
}