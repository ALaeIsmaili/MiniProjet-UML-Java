package ma.est.biblio.service;

import ma.est.biblio.dao.BiblioDao;
import ma.est.biblio.model.Livre;
import ma.est.biblio.model.Utilisateur;
import java.util.List;

public class BiblioService {
    private BiblioDao dao = new BiblioDao();

    // --- AUTH ---
    public Utilisateur login(String u, String p) { return dao.checkLogin(u, p); }

    // --- LIVRES ---
    public void addBook(String isbn, String titre, String auteur, int stock) { 
        dao.ajouterLivre(new Livre(isbn, titre, auteur, stock)); 
    }
    
    public void deleteBook(String isbn) { 
        dao.supprimerLivre(isbn); 
    }
    
    public List<Livre> getAllBooks() { return dao.getLivres(); }

    // --- RECHERCHE (Keep this from your old code) ---
    public List<Livre> searchBooks(String keyword) {
        return dao.rechercheLivre(keyword);
    }
    // Add this inside BiblioService.java
    public void updateEmail(int uid, String mail) { dao.updateEmail(uid, mail); }

    // --- UTILISATEURS ---
    public void addUser(String username, String email, String password, String role) { 
        dao.ajouterUtilisateur(username, email, password, role); 
    }
    
    public void deleteUser(int id) { 
        dao.supprimerUtilisateur(id); 
    }
    
    public List<Utilisateur> getAllUsers() { return dao.getUtilisateurs(); }

    // --- EMPRUNTS (Basic) ---
    public String borrowBook(int uid, String isbn) { return dao.emprunter(uid, isbn); }
    public String returnBook(int uid, String isbn) { return dao.retourner(uid, isbn); }

    // --- EMPRUNTS (Advanced for New UI) ---
    // Needed for Admin Tab 3
    public List<String[]> getAllLoans() { 
        return dao.getAllEmprunts(); 
    }
    
    // Needed for User Tab 2 (Detailed view with timer)
    public List<String[]> getMyLoansDetails(int uid) { 
        return dao.getMesEmpruntsDetails(uid); 
    }
}