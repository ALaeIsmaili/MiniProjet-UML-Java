package ma.est.biblio.model;

public class Livre {
    private String isbn;
    private String titre;
    private String auteur; // Nouveau champ
    private int stock;

    // Constructeur mis à jour
    public Livre(String isbn, String titre, String auteur, int stock) {
        this.isbn = isbn;
        this.titre = titre;
        this.auteur = auteur;
        this.stock = stock;
    }

    // Constructeur compatibilité (si nécessaire)
    public Livre(String isbn, String titre, int stock) {
        this(isbn, titre, "Inconnu", stock);
    }

    public String getIsbn() { return isbn; }
    public String getTitre() { return titre; }
    public String getAuteur() { return auteur; }
    public int getStock() { return stock; }
}