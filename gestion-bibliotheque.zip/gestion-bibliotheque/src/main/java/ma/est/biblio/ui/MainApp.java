package ma.est.biblio.ui;

import ma.est.biblio.dao.BiblioDao;
import ma.est.biblio.model.Livre;
import ma.est.biblio.model.Utilisateur;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;

public class MainApp extends JFrame {
    private CardLayout cardLayout = new CardLayout();
    private JPanel mainPanel = new JPanel(cardLayout);
    private BiblioDao dao = new BiblioDao();
    private Utilisateur currentUser;

    // --- MODELS (Modified for Delete Buttons) ---
    // Col 5 is "Retourner"
    private DefaultTableModel adminLoanModel = new DefaultTableModel(new String[]{"User", "Livre", "Date Prêt", "Date Prévue", "Statut", "Action"}, 0);
    // Col 4 is "Supprimer"
    private DefaultTableModel adminBookModel = new DefaultTableModel(new String[]{"ISBN", "Titre", "Auteur", "Stock", "Action"}, 0);
    // Col 5 is "Supprimer"
    private DefaultTableModel adminUserModel = new DefaultTableModel(new String[]{"ID", "User", "Email", "Role", "Bloqué?", "Action"}, 0);
    
    // User tables
    private DefaultTableModel userBookModel; 
    private DefaultTableModel userLoanModel = new DefaultTableModel(new String[]{"Livre", "Statut", "Temps Restant"}, 0);

    // --- PROFILE COMPONENTS ---
    private JLabel lblProfileId = new JLabel("...");
    private JLabel lblProfileUser = new JLabel("...");
    private JLabel lblProfileRole = new JLabel("...");
    private JTextField txtProfileEmail = new JTextField(20);

    // --- SORTERS ---
    private TableRowSorter<DefaultTableModel> sorterBooks;
    private TableRowSorter<DefaultTableModel> sorterUsers;
    private TableRowSorter<DefaultTableModel> sorterLoans;

    public MainApp() {
        setTitle("Gestion Bibliothèque - EST Meknès (Admin Mode)");
        setSize(1100, 750);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        mainPanel.add(createLoginPanel(), "LOGIN");
        mainPanel.add(createAdminPanel(), "ADMIN");
        mainPanel.add(createUserPanel(), "USER");
        add(mainPanel);
    }

    private JPanel createLoginPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(10,10,10,10); 
        
        JTextField userTxt = new JTextField(15);
        JPasswordField passTxt = new JPasswordField(15);
        
        g.gridx=0; g.gridy=0; p.add(new JLabel("Utilisateur:"), g);
        g.gridx=1; p.add(userTxt, g);
        g.gridx=0; g.gridy=1; p.add(new JLabel("Mot de passe:"), g);
        g.gridx=1; p.add(passTxt, g);
        
        JButton btn = new JButton("SE CONNECTER");
        btn.setBackground(new Color(70, 130, 180));
        btn.setForeground(Color.WHITE);
        g.gridy=2; g.gridwidth=2; p.add(btn, g);

        btn.addActionListener(e -> {
            currentUser = dao.checkLogin(userTxt.getText(), new String(passTxt.getPassword()));
            if (currentUser != null) {
                if (currentUser.getRole().equals("ADMIN")) {
                    refreshAdminData();
                    cardLayout.show(mainPanel, "ADMIN");
                } else {
                    refreshUserData();
                    cardLayout.show(mainPanel, "USER");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Identifiants incorrects !", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        });
        return p;
    }

    private JPanel createAdminPanel() {
        JTabbedPane tabs = new JTabbedPane();

        // --- TAB 1: GESTION LIVRES ---
        JPanel pLivres = new JPanel(new BorderLayout());
        JPanel topL = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField searchBook = new JTextField(15);
        JTextField isbn = new JTextField(5), titre = new JTextField(8), auteur = new JTextField(8), stock = new JTextField(3);
        JButton addL = new JButton("Ajouter"); // Removed 'Supprimer' button from top
        
        topL.add(new JLabel("🔍 Recherche:")); topL.add(searchBook);
        topL.add(new JSeparator(SwingConstants.VERTICAL));
        topL.add(new JLabel("Nouveau -> ISBN:")); topL.add(isbn);
        topL.add(new JLabel("Titre:")); topL.add(titre);
        topL.add(new JLabel("Auteur:")); topL.add(auteur);
        topL.add(new JLabel("Stock:")); topL.add(stock);
        topL.add(addL);

        // Table Configuration
        JTable tableBooks = new JTable(adminBookModel) {
            @Override public boolean isCellEditable(int row, int col) { return col == 4; } // Col 4 is button
        };
        tableBooks.getColumnModel().getColumn(4).setCellRenderer(new DeleteButtonRenderer());
        tableBooks.getColumnModel().getColumn(4).setCellEditor(new DeleteBookEditor(new JCheckBox()));

        sorterBooks = new TableRowSorter<>(adminBookModel);
        tableBooks.setRowSorter(sorterBooks);
        pLivres.add(topL, BorderLayout.NORTH);
        pLivres.add(new JScrollPane(tableBooks), BorderLayout.CENTER);

        // Logic
        addL.addActionListener(e -> { 
            dao.ajouterLivre(new Livre(isbn.getText(), titre.getText(), auteur.getText(), Integer.parseInt(stock.getText()))); 
            refreshAdminData(); 
        });
        searchBook.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent e) { sorterBooks.setRowFilter(RowFilter.regexFilter("(?i)" + searchBook.getText())); }
        });

        // --- TAB 2: GESTION UTILISATEURS ---
        JPanel pUsers = new JPanel(new BorderLayout());
        JPanel topU = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField searchUser = new JTextField(15);
        JTextField uName = new JTextField(8), uEmail = new JTextField(10), uPass = new JTextField(8);
        JComboBox<String> uRole = new JComboBox<>(new String[]{"USER", "ADMIN"}); 
        JButton addU = new JButton("Ajouter"); // Removed 'Supprimer' button from top

        topU.add(new JLabel("🔍 Recherche:")); topU.add(searchUser);
        topU.add(new JSeparator(SwingConstants.VERTICAL));
        topU.add(new JLabel("User:")); topU.add(uName);
        topU.add(new JLabel("Email:")); topU.add(uEmail);
        topU.add(new JLabel("Pass:")); topU.add(uPass);
        topU.add(uRole);
        topU.add(addU);

        // Table Configuration
        JTable tableUsers = new JTable(adminUserModel) {
            @Override public boolean isCellEditable(int row, int col) { return col == 5; } // Col 5 is button
        };
        tableUsers.getColumnModel().getColumn(5).setCellRenderer(new DeleteButtonRenderer());
        tableUsers.getColumnModel().getColumn(5).setCellEditor(new DeleteUserEditor(new JCheckBox()));

        sorterUsers = new TableRowSorter<>(adminUserModel);
        tableUsers.setRowSorter(sorterUsers);
        pUsers.add(topU, BorderLayout.NORTH);
        pUsers.add(new JScrollPane(tableUsers), BorderLayout.CENTER);

        // Logic
        addU.addActionListener(e -> { 
            dao.ajouterUtilisateur(uName.getText(), uEmail.getText(), uPass.getText(), (String)uRole.getSelectedItem()); 
            refreshAdminData(); 
        });
        searchUser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent e) { sorterUsers.setRowFilter(RowFilter.regexFilter("(?i)" + searchUser.getText())); }
        });

        // --- TAB 3: GESTION EMPRUNTS ---
        JPanel pLoans = new JPanel(new BorderLayout());
        JPanel topLoans = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField searchLoan = new JTextField(20);
        topLoans.add(new JLabel("🔍 Filtrer:")); topLoans.add(searchLoan);
        
        JTable tableLoans = new JTable(adminLoanModel) {
             @Override public boolean isCellEditable(int row, int column) { return column == 5; }
        };
        tableLoans.getColumnModel().getColumn(5).setCellRenderer(new AdminReturnRenderer());
        tableLoans.getColumnModel().getColumn(5).setCellEditor(new AdminReturnEditor(new JCheckBox()));
        
        sorterLoans = new TableRowSorter<>(adminLoanModel);
        tableLoans.setRowSorter(sorterLoans);

        pLoans.add(topLoans, BorderLayout.NORTH);
        pLoans.add(new JScrollPane(tableLoans), BorderLayout.CENTER);

        searchLoan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent e) { sorterLoans.setRowFilter(RowFilter.regexFilter("(?i)" + searchLoan.getText())); }
        });

        tabs.add("📚 Livres", pLivres);
        tabs.add("👥 Utilisateurs", pUsers);
        tabs.add("⏳ Emprunts", pLoans);

        JPanel container = new JPanel(new BorderLayout());
        JButton logout = new JButton("Déconnexion");
        logout.addActionListener(e -> cardLayout.show(mainPanel, "LOGIN"));
        container.add(tabs, BorderLayout.CENTER);
        container.add(logout, BorderLayout.SOUTH);
        return container;
    }

    private JPanel createUserPanel() {
        JPanel container = new JPanel(new BorderLayout());
        JTabbedPane tabs = new JTabbedPane();

        // TAB 1: CATALOGUE
        userBookModel = new DefaultTableModel(new String[]{"ISBN", "Titre", "Auteur", "Stock", "Action"}, 0) {
            @Override public boolean isCellEditable(int row, int col) { return col == 4; }
        };
        JTable bookTable = new JTable(userBookModel);
        bookTable.getColumnModel().getColumn(4).setCellRenderer(new UserBorrowRenderer());
        bookTable.getColumnModel().getColumn(4).setCellEditor(new UserBorrowEditor(new JCheckBox()));
        
        JPanel pCat = new JPanel(new BorderLayout());
        pCat.add(new JScrollPane(bookTable), BorderLayout.CENTER);

        // TAB 2: MES EMPRUNTS
        JTable loanTable = new JTable(userLoanModel);
        JPanel pMyLoans = new JPanel(new BorderLayout());
        pMyLoans.add(new JScrollPane(loanTable), BorderLayout.CENTER);

        // TAB 3: MON PROFIL
        JPanel pProfile = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(10,10,10,10);
        g.gridx=0; g.gridy=0; 
        
        JButton btnSave = new JButton("Mettre à jour Email");

        pProfile.add(new JLabel("ID:"), g); g.gridx=1; pProfile.add(lblProfileId, g);
        g.gridx=0; g.gridy=1; pProfile.add(new JLabel("Username:"), g); g.gridx=1; pProfile.add(lblProfileUser, g);
        g.gridx=0; g.gridy=2; pProfile.add(new JLabel("Role:"), g); g.gridx=1; pProfile.add(lblProfileRole, g);
        g.gridx=0; g.gridy=3; pProfile.add(new JLabel("Gmail:"), g); g.gridx=1; pProfile.add(txtProfileEmail, g);
        g.gridy=4; pProfile.add(btnSave, g);

        btnSave.addActionListener(e -> {
            dao.updateEmail(currentUser.getId(), txtProfileEmail.getText());
            JOptionPane.showMessageDialog(this, "Email mis à jour avec succès !");
        });

        tabs.add("Catalogue", pCat);
        tabs.add("Mes Emprunts", pMyLoans);
        tabs.add("Mon Profil", pProfile);

        JButton logout = new JButton("Déconnexion");
        logout.addActionListener(e -> cardLayout.show(mainPanel, "LOGIN"));
        
        container.add(tabs, BorderLayout.CENTER);
        container.add(logout, BorderLayout.SOUTH);
        return container;
    }

    private void refreshAdminData() {
        // Books (Added "Supprimer" string)
        adminBookModel.setRowCount(0);
        for(Livre l : dao.getLivres()) adminBookModel.addRow(new Object[]{l.getIsbn(), l.getTitre(), l.getAuteur(), l.getStock(), "Supprimer"});
        
        // Users (Added "Supprimer" string)
        adminUserModel.setRowCount(0);
        for(Utilisateur u : dao.getUtilisateurs()) {
            adminUserModel.addRow(new Object[]{u.getId(), u.getUsername(), "...", u.getRole(), u.isEstBloque() ? "OUI" : "NON", "Supprimer"});
        }
        
        // Loans
        adminLoanModel.setRowCount(0);
        for(String[] row : dao.getAllEmprunts()) {
            adminLoanModel.addRow(new Object[]{row[0], row[1], row[2], row[3], row[4], "Retourner"});
        }
    }

    private void refreshUserData() {
        if(currentUser == null) return;
        userBookModel.setRowCount(0);
        if (currentUser.isEstBloque()) JOptionPane.showMessageDialog(this, "COMPTE BLOQUÉ: Retards !", "Alerte", JOptionPane.ERROR_MESSAGE);
        for(Livre l : dao.getLivres()) userBookModel.addRow(new Object[]{l.getIsbn(), l.getTitre(), l.getAuteur(), l.getStock(), "Emprunter"});
        userLoanModel.setRowCount(0);
        for(String[] row : dao.getMesEmpruntsDetails(currentUser.getId())) userLoanModel.addRow(row);
        
        lblProfileId.setText(String.valueOf(currentUser.getId()));
        lblProfileUser.setText(currentUser.getUsername());
        lblProfileRole.setText(currentUser.getRole());
    }

    // --- BUTTON LOGIC ---

    // 1. GENERIC RED DELETE BUTTON RENDERER
    class DeleteButtonRenderer extends JButton implements TableCellRenderer {
        public DeleteButtonRenderer() { 
            setOpaque(true); 
            setText("Supprimer"); 
            setBackground(Color.RED); 
            setForeground(Color.WHITE);
        }
        public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) { return this; }
    }

    // 2. DELETE BOOK EDITOR
    class DeleteBookEditor extends DefaultCellEditor {
        JButton btn; boolean clicked; JTable table; int row;
        public DeleteBookEditor(JCheckBox cb) { super(cb); btn = new JButton("Supprimer"); btn.addActionListener(e -> fireEditingStopped()); }
        public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int r, int c) { table=t; row=r; clicked=true; return btn; }
        public Object getCellEditorValue() {
            if(clicked) {
                String isbn = (String) table.getValueAt(row, 0); // ISBN is Col 0
                int confirm = JOptionPane.showConfirmDialog(btn, "Voulez-vous vraiment supprimer le livre : " + isbn + " ?", "Confirmation", JOptionPane.YES_NO_OPTION);
                if(confirm == JOptionPane.YES_OPTION) {
                    dao.supprimerLivre(isbn);
                    refreshAdminData();
                }
            }
            clicked = false; return "Supprimer";
        }
    }

    // 3. DELETE USER EDITOR
    class DeleteUserEditor extends DefaultCellEditor {
        JButton btn; boolean clicked; JTable table; int row;
        public DeleteUserEditor(JCheckBox cb) { super(cb); btn = new JButton("Supprimer"); btn.addActionListener(e -> fireEditingStopped()); }
        public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int r, int c) { table=t; row=r; clicked=true; return btn; }
        public Object getCellEditorValue() {
            if(clicked) {
                int id = (int) table.getValueAt(row, 0); // ID is Col 0
                int confirm = JOptionPane.showConfirmDialog(btn, "Voulez-vous vraiment supprimer l'utilisateur ID: " + id + " ?", "Confirmation", JOptionPane.YES_NO_OPTION);
                if(confirm == JOptionPane.YES_OPTION) {
                    dao.supprimerUtilisateur(id);
                    refreshAdminData();
                }
            }
            clicked = false; return "Supprimer";
        }
    }

    // 4. ADMIN RETURN RENDERER
    class AdminReturnRenderer extends JButton implements TableCellRenderer {
        public AdminReturnRenderer() { setOpaque(true); setText("Retourner"); }
        public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) { return this; }
    }
    class AdminReturnEditor extends DefaultCellEditor {
        JButton btn; boolean clicked;
        public AdminReturnEditor(JCheckBox cb) { super(cb); btn = new JButton("Retourner"); btn.addActionListener(e -> fireEditingStopped()); }
        public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int r, int c) { clicked=true; return btn; }
        public Object getCellEditorValue() { 
            if(clicked) {
                String uid = JOptionPane.showInputDialog(btn, "ID Utilisateur:");
                String bisbn = JOptionPane.showInputDialog(btn, "ISBN Livre:");
                if(uid!=null && bisbn!=null) {
                     JOptionPane.showMessageDialog(btn, dao.retourner(Integer.parseInt(uid), bisbn));
                     refreshAdminData();
                }
            }
            clicked = false; return "Retourner"; 
        }
    }

    // 5. USER BORROW RENDERER
    class UserBorrowRenderer extends JButton implements TableCellRenderer {
        public UserBorrowRenderer() { setOpaque(true); setText("Emprunter"); }
        public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) { return this; }
    }
    class UserBorrowEditor extends DefaultCellEditor {
        JButton btn; boolean clicked; JTable table; int row;
        public UserBorrowEditor(JCheckBox cb) { super(cb); btn = new JButton("Emprunter"); btn.addActionListener(e -> fireEditingStopped()); }
        public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int r, int c) { table=t; row=r; clicked=true; return btn; }
        public Object getCellEditorValue() {
            if(clicked) {
                String isbn = (String) table.getValueAt(row, 0); 
                String msg = dao.emprunter(currentUser.getId(), isbn);
                JOptionPane.showMessageDialog(btn, msg);
                refreshUserData();
            }
            clicked = false; return "Emprunter";
        }
    }

    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new MainApp().setVisible(true)); }
}