package ma.est.biblio.dao;

import ma.est.biblio.model.Livre;
import ma.est.biblio.model.Utilisateur;
import ma.est.biblio.util.DBConnection;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BiblioDao {

    // --- AUTOMATIC UPDATE ---
    public void updateSystemStatuses() {
        try (Connection conn = DBConnection.getConnection()) {
            String sqlRetard = "UPDATE emprunt SET statut = 'RETARD' WHERE date_retour_prevue < CURRENT_DATE AND date_retour_effectif IS NULL";
            conn.createStatement().executeUpdate(sqlRetard);

            String sqlBlock = "UPDATE users SET est_bloque = TRUE WHERE id IN (" +
                              "SELECT user_id FROM emprunt WHERE DATEDIFF(CURRENT_DATE, date_retour_prevue) > 10 " +
                              "AND date_retour_effectif IS NULL)";
            conn.createStatement().executeUpdate(sqlBlock);
        } catch (Exception e) { e.printStackTrace(); }
    }

    // --- AUTHENTIFICATION ---
    public Utilisateur checkLogin(String user, String pass) {
        updateSystemStatuses(); 
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM users WHERE username=? AND password=?")) {
            stmt.setString(1, user);
            stmt.setString(2, pass);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Utilisateur(rs.getInt("id"), rs.getString("username"), rs.getString("role"), rs.getBoolean("est_bloque"));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    // --- GESTION LIVRES ---
    public void ajouterLivre(Livre l) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO livre VALUES (?, ?, ?, ?)")) {
            stmt.setString(1, l.getIsbn());
            stmt.setString(2, l.getTitre());
            stmt.setString(3, l.getAuteur());
            stmt.setInt(4, l.getStock());
            stmt.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // [FIXED] Supprimer Livre: Deletes history first
    public void supprimerLivre(String isbn) {
        try (Connection conn = DBConnection.getConnection()) {
            // 1. Delete associated loans (history) first
            conn.createStatement().executeUpdate("DELETE FROM emprunt WHERE isbn='" + isbn + "'");
            // 2. Now delete the book
            conn.createStatement().executeUpdate("DELETE FROM livre WHERE isbn='" + isbn + "'");
        } catch (Exception e) { 
            e.printStackTrace(); 
            System.err.println("Erreur suppression livre: " + e.getMessage());
        }
    }

    public List<Livre> getLivres() {
        List<Livre> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM livre")) {
            while (rs.next()) list.add(new Livre(rs.getString("isbn"), rs.getString("titre"), rs.getString("auteur"), rs.getInt("stock")));
        } catch (Exception e) {}
        return list;
    }

    public List<Livre> rechercheLivre(String motCle) {
        List<Livre> list = new ArrayList<>();
        String sql = "SELECT * FROM livre WHERE titre LIKE ? OR isbn LIKE ? OR auteur LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            String pattern = "%" + motCle + "%";
            stmt.setString(1, pattern);
            stmt.setString(2, pattern);
            stmt.setString(3, pattern);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) list.add(new Livre(rs.getString("isbn"), rs.getString("titre"), rs.getString("auteur"), rs.getInt("stock")));
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // --- GESTION UTILISATEURS ---
    public void ajouterUtilisateur(String u, String e, String p, String r) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO users (username, email, password, role) VALUES (?,?,?,?)")) {
            ps.setString(1, u); ps.setString(2, e); ps.setString(3, p); ps.setString(4, r);
            ps.executeUpdate();
        } catch (Exception ex) { ex.printStackTrace(); }
    }

    public void updateEmail(int userId, String newEmail) {
        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("UPDATE users SET email=? WHERE id=?");
            ps.setString(1, newEmail);
            ps.setInt(2, userId);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // [FIXED] Supprimer Utilisateur: Deletes history first
    public void supprimerUtilisateur(int id) {
        try (Connection conn = DBConnection.getConnection()) {
            // 1. Delete associated loans first
            conn.createStatement().executeUpdate("DELETE FROM emprunt WHERE user_id=" + id);
            // 2. Delete the user
            conn.createStatement().executeUpdate("DELETE FROM users WHERE id=" + id);
        } catch (Exception e) { 
            e.printStackTrace(); 
            System.err.println("Erreur suppression user: " + e.getMessage());
        }
    }

    public List<Utilisateur> getUtilisateurs() {
        List<Utilisateur> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM users")) {
            while (rs.next()) list.add(new Utilisateur(rs.getInt("id"), rs.getString("username"), rs.getString("role"), rs.getBoolean("est_bloque")));
        } catch (Exception e) {}
        return list;
    }

    // --- EMPRUNTS ---
    public String emprunter(int userId, String isbn) {
        updateSystemStatuses();
        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement cb = conn.prepareStatement("SELECT est_bloque FROM users WHERE id=?");
            cb.setInt(1, userId); ResultSet rsb = cb.executeQuery();
            if (rsb.next() && rsb.getBoolean("est_bloque")) return "COMPTE BLOQUÉ (Retard > 10j)";

            PreparedStatement cd = conn.prepareStatement("SELECT COUNT(*) FROM emprunt WHERE user_id=? AND isbn=? AND date_retour_effectif IS NULL");
            cd.setInt(1, userId); cd.setString(2, isbn); ResultSet rsd = cd.executeQuery(); rsd.next();
            if (rsd.getInt(1) > 0) return "Vous avez déjà ce livre !";

            PreparedStatement cl = conn.prepareStatement("SELECT COUNT(*) FROM emprunt WHERE user_id=? AND date_retour_effectif IS NULL");
            cl.setInt(1, userId); ResultSet rsl = cl.executeQuery(); rsl.next();
            if (rsl.getInt(1) >= 3) return "Limite de 3 emprunts atteinte.";

            PreparedStatement cs = conn.prepareStatement("SELECT stock FROM livre WHERE isbn=?");
            cs.setString(1, isbn); ResultSet rss = cs.executeQuery();
            if (!rss.next() || rss.getInt("stock") <= 0) return "Stock épuisé.";

            conn.createStatement().executeUpdate("UPDATE livre SET stock=stock-1 WHERE isbn='" + isbn + "'");
            LocalDate ret = LocalDate.now().plusDays(14);
            PreparedStatement ins = conn.prepareStatement("INSERT INTO emprunt (user_id, isbn, date_emprunt, date_retour_prevue, statut) VALUES (?, ?, NOW(), ?, 'EN_COURS')");
            ins.setInt(1, userId); ins.setString(2, isbn); ins.setDate(3, java.sql.Date.valueOf(ret));
            ins.executeUpdate();
            return "Emprunt validé (Retour: " + ret + ")";
        } catch (Exception e) { return "Erreur: " + e.getMessage(); }
    }

    public String retourner(int userId, String isbn) {
        try (Connection conn = DBConnection.getConnection()) {
            int c = conn.createStatement().executeUpdate("UPDATE emprunt SET date_retour_effectif=NOW(), statut='RENDU' WHERE user_id=" + userId + " AND isbn='" + isbn + "' AND date_retour_effectif IS NULL");
            if (c > 0) {
                conn.createStatement().executeUpdate("UPDATE livre SET stock=stock+1 WHERE isbn='" + isbn + "'");
                return "Retour enregistré.";
            }
        } catch (Exception e) {}
        return "Erreur lors du retour.";
    }

    public List<String[]> getAllEmprunts() {
        List<String[]> list = new ArrayList<>();
        String sql = "SELECT u.username, l.titre, e.date_emprunt, e.date_retour_prevue, e.statut, DATEDIFF(e.date_retour_prevue, CURRENT_DATE) as j FROM emprunt e JOIN users u ON e.user_id=u.id JOIN livre l ON e.isbn=l.isbn WHERE e.date_retour_effectif IS NULL";
        try (Connection conn = DBConnection.getConnection(); ResultSet rs = conn.createStatement().executeQuery(sql)) {
            while (rs.next()) {
                int j = rs.getInt("j");
                list.add(new String[]{rs.getString("username"), rs.getString("titre"), rs.getString("date_emprunt"), rs.getString("date_retour_prevue"), (j < 0 ? "RETARD " + Math.abs(j) + "j" : j + "j restants"), rs.getString("statut")});
            }
        } catch (Exception e) {}
        return list;
    }

    public List<String[]> getMesEmpruntsDetails(int userId) {
        List<String[]> list = new ArrayList<>();
        String sql = "SELECT l.titre, e.statut, DATEDIFF(e.date_retour_prevue, CURRENT_DATE) as j FROM emprunt e JOIN livre l ON e.isbn=l.isbn WHERE e.user_id=" + userId + " AND e.date_retour_effectif IS NULL";
        try (Connection conn = DBConnection.getConnection(); ResultSet rs = conn.createStatement().executeQuery(sql)) {
            while (rs.next()) {
                int j = rs.getInt("j");
                list.add(new String[]{rs.getString("titre"), rs.getString("statut"), (j < 0 ? "RETARD " + Math.abs(j) + "j" : j + "j restants")});
            }
        } catch (Exception e) {}
        return list;
    }
}